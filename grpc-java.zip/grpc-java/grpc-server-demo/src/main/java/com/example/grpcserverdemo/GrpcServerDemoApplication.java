package com.example.grpcserverdemo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class GrpcServerDemoApplication {

    public static void main(String[] args) {
        SpringApplication.run(GrpcServerDemoApplication.class, args);
    }

}
