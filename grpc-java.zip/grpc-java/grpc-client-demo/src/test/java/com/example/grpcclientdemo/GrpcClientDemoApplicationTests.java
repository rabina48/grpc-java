package com.example.grpcclientdemo;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class GrpcClientDemoApplicationTests {

    @Test
    void contextLoads() {
    }

}
