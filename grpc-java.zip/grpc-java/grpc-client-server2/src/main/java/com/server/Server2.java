package com.server;

import com.example.grpcclientserver2.service.YourServiceImplementation;
import io.grpc.Server;
import io.grpc.ServerBuilder;

import java.io.IOException;

public class Server2 {

    public static void main(String[] args) throws IOException, InterruptedException {
        Server server = ServerBuilder.forPort(2021)
                .addService(new YourServiceImplementation())
                .build();

        server.start();
        System.out.println("gRPC server started on port 2021");



        server.awaitTermination();
    }
}
